<!-- id="particles-js" -->
<!-- slider-area start -->
    

    <div class="slider-area">
    <div id="particles-js" style="z-index:2;"></div>
        <div class="slider-active">
            <div class="slider-items">
                <img src="assets/images/img/ERENDI4.jpg" alt="slider" class="slider">
                <div class="single-slider">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <h2 style="color: white;">WE ARE</h2>
                                <h2>ERENDI</h2>
                                <h2 style="color: #dc3545;">DIGITAL LABS</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="slider-items">
                <img src="assets/images/img/ERENDI1.jpg" alt="slider" class="slider">
                <div class="single-slider single-slider2">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-offset-2 col-sm-10 col-xs-12 col-md-12 col-md-offset-0 text-right">
                                <h2 style="color: white;">WE ARE</h2>
                                <h2>ERENDI</h2>
                                <h2 style="color: #dc3545;">DIGITAL LABS</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="slider-items">
                <img src="assets/images/img/ERENDI3.jpg" alt="slider" class="slider">
                <div class="single-slider">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <h2 style="color: white;">WE ARE</h2>
                                <h2>ERENDI</h2>
                                <h2 style="color: #dc3545;">DIGITAL LABS</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- slider-area end -->